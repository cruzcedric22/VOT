<?php
include('config.php');
if(isset($_POST['delvoter_submit'])){

$deleteid = $_POST['delstff_id'];


$delete1 = "UPDATE vot_user_profile SET status = 1 WHERE student_no ='$deleteid'";
if($conn -> query($delete1)){
    echo "<script> alert('User Verified'); </script>";
    echo "<script> setTimeout(() => {
        window.location.href = 'list_voters.php'
    },1); </script>";
}else{
    die ($conn -> error);
}


}

if(isset($_POST['delvoter_inactive'])){

    $deleteid = $_POST['delstff_id'];
    
    
    $delete1 = "UPDATE vot_user_profile SET status = 2 WHERE student_no ='$deleteid'";
    if($conn -> query($delete1)){
        echo "<script> alert('User Inactive'); </script>";
        echo "<script> setTimeout(() => {
            window.location.href = 'list_voters.php'
        },1); </script>";
    }else{
        die ($conn -> error);
    }
    
    
    }

    if(isset($_POST['delvoter_active'])){

        $deleteid = $_POST['delstff_id'];
        
        
        $delete1 = "UPDATE vot_user_profile SET status = 1 WHERE student_no ='$deleteid'";
        if($conn -> query($delete1)){
            echo "<script> alert('User Active'); </script>";
            echo "<script> setTimeout(() => {
                window.location.href = 'list_voters.php'
            },1); </script>";
        }else{
            die ($conn -> error);
        }
        
        
        }

